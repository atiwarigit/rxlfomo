# FOMO Portfolio Dashboard

A clean starting point for managing your FOMO (fomo.family) memecoin portfolio — PnL, risk, concentration, and influence metrics.

Built so you can push it to GitHub and iterate with an AI coding agent (Cursor, Claude Code, Copilot, etc.).

## What’s included

- **Overview cards**: Total equity, realized / unrealized PnL, cash %, drawdown, win rate
- **Equity curve**: Simple historical performance chart
- **Open positions table**: Size, % of portfolio, unrealized PnL, mcap move, hold time, chain, thesis
- **Risk panel**: Cash buffer, concentration (largest + top-3), drawdown, suggested rules that scale with size
- **Mock data** that looks like a ~$1.1M FOMO book so you can see the UI immediately

## Quick start

```bash
# 1. Clone or download this repo
git clone <your-repo-url>
cd fomo-portfolio-dashboard

# 2. Install
npm install

# 3. Run
npm run dev
```

Open http://localhost:5173

## Project structure

```
src/
├── components/
│   ├── StatCard.tsx
│   ├── EquityChart.tsx
│   ├── PositionsTable.tsx
│   └── RiskPanel.tsx
├── data/
│   └── mockPortfolio.ts      ← replace this with real data
├── lib/
│   └── format.ts
├── types/
│   └── portfolio.ts
├── App.tsx
├── index.css
└── main.tsx
```

## Next steps for real data

1. **FOMO handle + wallets**  
   Note your FOMO handle and the Solana/EVM addresses linked to it.

2. **Replace mock data**  
   Edit `src/data/mockPortfolio.ts` or create a data-fetching layer:
   - Unofficial FOMO APIs (e.g. fomoapi.io) for trades, balances, PnL
   - On-chain (Helius / your RPC) for verification
   - CSV export from CoinStats or manual journal

3. **Add features the AI agent can help with**
   - Trade journal with R-multiples
   - CSV / Google Sheets import
   - Telegram alerts on drawdown or position size breaches
   - Historical performance by setup type (copy vs thesis vs launch)
   - Position size calculator that respects your risk rules

4. **Risk rules to hard-code later**
   - Max % of equity per single name (e.g. 12–15% once equity > $500k)
   - Minimum cash buffer
   - Automatic size reduction after X% drawdown from peak

## Tech stack

- Vite + React 19 + TypeScript
- Tailwind CSS v4
- Recharts
- Lucide icons

## License

MIT — use it, fork it, make it yours.

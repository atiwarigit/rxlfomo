export interface Position {
  id: string;
  token: string;
  symbol: string;
  chain: 'solana' | 'base' | 'bnb' | 'monad' | 'other';
  sizeUsd: number;
  entryPrice: number;
  currentPrice: number;
  entryMcap: number;
  currentMcap: number;
  unrealizedPnl: number;
  unrealizedPnlPct: number;
  holdTimeHours: number;
  entryDate: string;
  thesis?: string;
  liquidityUsd?: number;
}

export interface ClosedTrade {
  id: string;
  token: string;
  symbol: string;
  chain: string;
  side: 'long';
  sizeUsd: number;
  entryPrice: number;
  exitPrice: number;
  realizedPnl: number;
  realizedPnlPct: number;
  holdTimeHours: number;
  entryDate: string;
  exitDate: string;
  rMultiple?: number;
  notes?: string;
}

export interface EquityPoint {
  date: string;
  equity: number;
  realizedPnl: number;
}

export interface PortfolioSummary {
  totalEquity: number;
  cashUsd: number;
  openPositionsValue: number;
  realizedPnlAllTime: number;
  unrealizedPnl: number;
  peakEquity: number;
  currentDrawdownPct: number;
  winRate: number;
  profitFactor: number;
  avgRMultiple: number;
  totalTrades: number;
  followers: number;
  leaderboardRank?: number;
}

import { StatCard } from './components/StatCard';
import { EquityChart } from './components/EquityChart';
import { PositionsTable } from './components/PositionsTable';
import { RiskPanel } from './components/RiskPanel';
import { summary, openPositions, equityCurve } from './data/mockPortfolio';
import { formatUsd, formatPct } from './lib/format';
import { TrendingUp, Users, Activity, Wallet } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-[#0b0f19] text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/40 px-6 py-4">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              FOMO Portfolio Dashboard
            </h1>
            <p className="text-sm text-white/50">
              Risk · Reward · Influence · Starting point for your edge
            </p>
          </div>
          <div className="flex items-center gap-4 text-sm text-white/60">
            <span className="flex items-center gap-1.5">
              <Users size={16} /> {summary.followers.toLocaleString()} followers
            </span>
            {summary.leaderboardRank && (
              <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-emerald-400">
                Rank #{summary.leaderboardRank}
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-6 py-6">
        {/* Key metrics */}
        <section className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
          <StatCard
            label="Total Equity"
            value={formatUsd(summary.totalEquity, true)}
            sub="Cash + open positions"
            trend="neutral"
          />
          <StatCard
            label="Realized PnL"
            value={formatUsd(summary.realizedPnlAllTime, true)}
            sub="All-time closed"
            trend="up"
          />
          <StatCard
            label="Unrealized"
            value={formatUsd(summary.unrealizedPnl, true)}
            sub={formatPct((summary.unrealizedPnl / summary.openPositionsValue) * 100)}
            trend={summary.unrealizedPnl >= 0 ? 'up' : 'down'}
          />
          <StatCard
            label="Cash"
            value={formatUsd(summary.cashUsd, true)}
            sub={`${((summary.cashUsd / summary.totalEquity) * 100).toFixed(0)}% of equity`}
            trend="neutral"
          />
          <StatCard
            label="Drawdown"
            value={formatPct(summary.currentDrawdownPct)}
            sub={`Peak ${formatUsd(summary.peakEquity, true)}`}
            trend={summary.currentDrawdownPct < -5 ? 'down' : 'neutral'}
          />
          <StatCard
            label="Win Rate"
            value={`${summary.winRate}%`}
            sub={`PF ${summary.profitFactor} · ${summary.totalTrades} trades`}
            trend="up"
          />
        </section>

        {/* Chart + Risk */}
        <section className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 lg:col-span-2">
            <div className="mb-3 flex items-center gap-2">
              <TrendingUp size={18} className="text-emerald-400" />
              <h2 className="font-semibold">Equity Curve</h2>
            </div>
            <EquityChart data={equityCurve} />
          </div>
          <RiskPanel summary={summary} positions={openPositions} />
        </section>

        {/* Open positions */}
        <section>
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wallet size={18} className="text-sky-400" />
              <h2 className="font-semibold">Open Positions</h2>
              <span className="rounded-full bg-white/10 px-2 py-0.5 text-xs">
                {openPositions.length}
              </span>
            </div>
            <p className="text-sm text-white/50">
              Total open: {formatUsd(summary.openPositionsValue)}
            </p>
          </div>
          <PositionsTable positions={openPositions} totalEquity={summary.totalEquity} />
        </section>

        {/* Next steps footer */}
        <section className="rounded-xl border border-dashed border-white/20 bg-white/5 p-5 text-sm text-white/70">
          <div className="flex items-start gap-3">
            <Activity size={20} className="mt-0.5 shrink-0 text-violet-400" />
            <div>
              <p className="font-medium text-white">How to evolve this dashboard</p>
              <ul className="mt-2 list-inside list-disc space-y-1">
                <li>Replace <code className="rounded bg-black/40 px-1">src/data/mockPortfolio.ts</code> with real FOMO API / wallet data</li>
                <li>Add a CSV upload or Google Sheets sync for closed trades</li>
                <li>Wire R-multiple tracking + trade journal</li>
                <li>Add alerts (Telegram / Discord) for drawdown or concentration breaches</li>
                <li>Push to GitHub and iterate with your AI coding agent (Cursor, Claude, etc.)</li>
              </ul>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
